from pathlib import Path
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

folder = Path(__file__).parent
data = pd.read_csv(folder / "MoviesOnStreamingPlatforms.csv")
platforms = ["Netflix", "Hulu", "Prime Video", "Disney+"]

print("Rows and columns:", data.shape)
print("Missing values before cleaning:\n", data.isna().sum().to_string())

# Clean the columns used in the charts.
data = data.drop(columns=["Unnamed: 0", "Type"], errors="ignore")
data["Year"] = pd.to_numeric(data["Year"], errors="coerce")
data["Rotten Tomatoes score"] = pd.to_numeric(
    data["Rotten Tomatoes"].str.replace("/100", "", regex=False), errors="coerce"
)
data["Age"] = data["Age"].fillna("Not listed")

print("Missing values after cleaning:\n", data.isna().sum().to_string())
print("\nMovie listings by service:\n", data[platforms].sum().to_string())

sns.set_theme(style="whitegrid", palette="Set2")

# Put each movie-service pair on its own row so the charts are easy to compare.
movies = data.melt(
    id_vars=["ID", "Title", "Year", "Age", "Rotten Tomatoes score"],
    value_vars=platforms, var_name="Platform", value_name="Available"
)
movies = movies[movies["Available"] == 1]

def save_chart(name):
    plt.tight_layout()
    plt.savefig(folder / name, dpi=150)

# 1. Movie listings by service
fig, ax = plt.subplots(figsize=(8, 5))
sns.countplot(data=movies, x="Platform", order=platforms, ax=ax)
ax.set(title="Movie listings by service", xlabel="Service", ylabel="Listings")
save_chart("01_listings_by_service.png")

# 2. How many services list each movie
data["Number of services"] = data[platforms].sum(axis=1)
fig, ax = plt.subplots(figsize=(7, 5))
sns.countplot(data=data, x="Number of services", ax=ax)
ax.set(title="Movies listed on one or more services", xlabel="Number of services", ylabel="Movies")
save_chart("02_service_overlap.png")

# 3. Movie release decades by service
movies["Release decade"] = (movies["Year"] // 10 * 10)
decades = movies[movies["Release decade"] >= 1940].dropna(subset=["Release decade"])
fig, ax = plt.subplots(figsize=(10, 5))
sns.countplot(data=decades, x="Release decade", hue="Platform", hue_order=platforms, ax=ax)
ax.set(title="Movie releases by decade", xlabel="Release decade", ylabel="Listings")
ax.tick_params(axis="x", rotation=35)
save_chart("03_release_decades.png")

# 4. Critics' Rotten Tomatoes scores by service
rated = movies.dropna(subset=["Rotten Tomatoes score"])
fig, ax = plt.subplots(figsize=(8, 5))
sns.boxplot(data=rated, x="Platform", y="Rotten Tomatoes score", order=platforms, showfliers=False, ax=ax)
ax.set(title="Critics' scores by service", xlabel="Service", ylabel="Score out of 100")
save_chart("04_scores_by_service.png")

# 5. Age labels in each service's catalog
fig, ax = plt.subplots(figsize=(9, 5))
sns.countplot(data=movies, x="Platform", hue="Age", order=platforms, ax=ax)
ax.set(title="Age labels by service", xlabel="Service", ylabel="Listings")
ax.legend(title="Age label", bbox_to_anchor=(1.02, 1), loc="upper left")
save_chart("05_age_labels.png")

# 6. Critics' scores by age label
fig, ax = plt.subplots(figsize=(8, 5))
sns.boxplot(data=rated, x="Age", y="Rotten Tomatoes score", showfliers=False, ax=ax)
ax.set(title="Critics' scores by age label", xlabel="Age label", ylabel="Score out of 100")
save_chart("06_score_by_age.png")

# 7. Score distributions across services
fig, ax = plt.subplots(figsize=(8, 5))
sns.histplot(data=rated, x="Rotten Tomatoes score", hue="Platform", hue_order=platforms,
             bins=20, element="step", stat="density", common_norm=False, ax=ax)
ax.set(title="Movie score distributions", xlabel="Rotten Tomatoes score", ylabel="Density")
save_chart("07_score_distributions.png")

# 8. Release year and critics' score
fig, ax = plt.subplots(figsize=(9, 5))
sns.scatterplot(data=rated, x="Year", y="Rotten Tomatoes score", hue="Platform",
                hue_order=platforms, alpha=0.3, s=12, ax=ax)
ax.set(title="Release year and critics' score", xlabel="Release year", ylabel="Score out of 100")
save_chart("08_year_vs_score.png")

# 9. Titles shared by pairs of services
overlap = data[platforms].T.dot(data[platforms])
fig, ax = plt.subplots(figsize=(7, 6))
sns.heatmap(overlap, annot=True, fmt=".0f", cmap="YlGnBu", ax=ax)
ax.set(title="Titles shared between services", xlabel="Service", ylabel="Service")
save_chart("09_service_overlap_heatmap.png")

print("\nNine charts saved beside this script.")
plt.show()

