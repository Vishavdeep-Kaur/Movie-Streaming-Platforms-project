# Streaming Catalog Case Study

## Purpose
This case study compares movie listings on Netflix, Hulu, Prime Video, and Disney+ to see how their catalogs differ. These comparisons may help viewers understand catalog choices and give streaming companies a starting point for thinking about content positioning.

## Main findings
In this historical dataset, Prime Video has the most listed movies, followed by Netflix, Hulu, and Disney+. Most movies appear on only one service. The average Rotten Tomatoes critics' score differs across the services, but this describes only the movies and scores captured in the dataset.

## Conclusion
The charts compare catalog size, overlap, release decades, age labels, and critics' scores. They do not show viewing behavior, subscriber preferences, revenue, or current service catalogs. The findings should be treated as descriptive comparisons, not a ranking of service quality.

## Source
Ruchi Bhatia, *Movies on Netflix, Prime Video, Hulu and Disney+*, Kaggle. CC0 Public Domain.
https://www.kaggle.com/datasets/ruchi798/movies-on-netflix-prime-video-hulu-and-disney
