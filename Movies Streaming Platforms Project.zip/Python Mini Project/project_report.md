# Streaming Movie Catalog Project Report

## Question
How do Netflix, Hulu, Prime Video, and Disney+ differ in the movies listed in this historical sample? The comparisons may help viewers compare catalogs and help companies think about catalog positioning.

## Dataset
The Kaggle dataset *Movies on Netflix, Prime Video, Hulu and Disney+* by Ruchi Bhatia has 9,515 movie records. It includes release year, age label, Rotten Tomatoes score, and one availability field for each service. Kaggle lists it as CC0 Public Domain. It is an older scraped snapshot, not a current catalog.

Source: https://www.kaggle.com/datasets/ruchi798/movies-on-netflix-prime-video-hulu-and-disney

## Steps
1. Downloaded the CSV from Kaggle and placed it beside the Python script.
2. Loaded the data with pandas and checked its size and missing values.
3. Removed the export-only row number and the constant `Type` column.
4. Converted release years and Rotten Tomatoes scores to numeric values.
5. Marked missing age labels as `Not listed`, keeping those movies in the analysis. Seven missing critics' scores are skipped only in score charts.
6. Reshaped the service columns to compare each platform in Seaborn.
7. Created nine charts and saved them beside the script.
8. Compared the charts with the printed counts and rating summaries.

## Findings
- The file has 4,113 Prime Video listings, 3,695 Netflix listings, 1,047 Hulu listings, and 922 Disney+ listings. A title can appear on more than one service.
- 9,262 titles appear on one service, 245 on two, 7 on three, and 1 on all four.
- Average Rotten Tomatoes critics' scores are 60.4 for Hulu, 58.3 for Disney+, 54.4 for Netflix, and 50.4 for Prime Video.

## Limits
This is a historical, scraped catalog snapshot. Rotten Tomatoes scores are critics' scores, not viewer ratings. The dataset has no views, subscribers, revenue, or licensing costs, so it cannot show which service performs best or what people actually watch.
